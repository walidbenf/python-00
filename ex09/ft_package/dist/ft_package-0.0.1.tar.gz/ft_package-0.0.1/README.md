# ft_package

pip uninstall ft_package
pip install build
python -m build
 pip install ./dist/ft_package-0.0.1-py3-none-any.whl